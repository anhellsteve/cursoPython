def potencia (num1, num2):
    print("La potencia es: ", num1 ** num2)

def redondear (num1):
    print("El numero redondeado es: ", round(num1))