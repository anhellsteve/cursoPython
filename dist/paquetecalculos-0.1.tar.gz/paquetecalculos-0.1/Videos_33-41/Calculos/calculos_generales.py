def sumar (num1, num2):
    print("La suma es: ", num1 + num2)

def restar (num1, num2):
    print("La resta es: ", num1 - num2)

def multiplicar (num1, num2):
    print("La multiplicación es: ", num1 * num2)

def dividir (num1, num2):
    if num2 == 0:
        print("No se puede dividir entre 0")
    else:
        print("La division es: ", num1 / num2)

def potencia (num1, num2):
    print("La potencia es: ", num1 ** num2)

def redondear (num1):
    print("El numero redondeado es: ", round(num1))
