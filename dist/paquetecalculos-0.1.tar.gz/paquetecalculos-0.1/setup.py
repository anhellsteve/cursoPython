from setuptools import setup

setup(
    name='paqueteCalculos',
    version='0.1',
    description='Paquete de redondeo y potencia',
    author='Anhell Steve',
    packages=['Videos_33-41.Calculos','Videos_33-41.Calculos.redondeo_potencia']
)

